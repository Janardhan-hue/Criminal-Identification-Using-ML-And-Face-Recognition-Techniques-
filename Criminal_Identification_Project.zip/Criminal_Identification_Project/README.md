# 🔍 Criminal Identification Using ML and Face Recognition  

## 📌 Overview  
This project focuses on building an **AI-powered criminal identification system** using **Machine Learning** and **Face Recognition techniques**.  

## 🚀 Features
- Face Detection & Recognition using CNNs  
- Machine Learning Models (SVM, Ensemble Methods)  
- Real-Time Identification from surveillance feeds  
- Privacy & Security Measures  
- Bias Mitigation & Fairness  

## 🛠️ Tech Stack
- Python, TensorFlow, Keras, OpenCV, Scikit-learn  
- MySQL / SQLite for database  
- Tools: Git, VS Code, Jupyter Notebook  

## ⚙️ Installation & Setup  
```bash
git clone https://github.com/your-username/criminal-identification-ml.git
cd criminal-identification-ml
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## 👨‍💻 Author
**Eduguttu Gopal**
