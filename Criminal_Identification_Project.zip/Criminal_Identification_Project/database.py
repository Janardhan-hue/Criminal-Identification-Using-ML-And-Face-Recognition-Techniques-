class CriminalDatabase:
    def __init__(self):
        self.criminals = {
            "001": "John Doe",
            "002": "Jane Smith",
            "003": "Unknown"
        }

    def match_face(self, features):
        return "John Doe"
