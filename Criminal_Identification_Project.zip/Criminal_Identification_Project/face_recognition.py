import cv2
import numpy as np
from sklearn.svm import SVC

class FaceRecognitionSystem:
    def __init__(self, db):
        self.db = db
        self.model = SVC(probability=True)

    def identify(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)

        results = []
        for (x, y, w, h) in faces:
            roi = gray[y:y+h, x:x+w]
            roi = cv2.resize(roi, (100, 100)).flatten().reshape(1, -1)
            name = self.db.match_face(roi)
            results.append((name, (x, y, w, h)))

        return results
