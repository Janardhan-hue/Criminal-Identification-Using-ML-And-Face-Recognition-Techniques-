import cv2
from face_recognition import FaceRecognitionSystem
from database import CriminalDatabase

def main():
    print("🚀 Criminal Identification System Started...")

    db = CriminalDatabase()
    recognizer = FaceRecognitionSystem(db)

    cap = cv2.VideoCapture(0)
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        results = recognizer.identify(frame)
        for (name, (x, y, w, h)) in results:
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
            cv2.putText(frame, name, (x, y-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

        cv2.imshow("Criminal Identification System", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
